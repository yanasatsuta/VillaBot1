googlebot = {
    'User-Agent': "Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)"}
iphone = {
    'user-agent': "Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1", }
android = {
    'user-agent': "Mozilla/5.0 (Linux; U; Android 4.4.2; en-us; LGMS323 Build/KOT49I.MS32310c) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/108.0.0.0 Mobile Safari/537.36"}
desktop = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0'}
url_feed = 'https://www.facebook.com/marketplace/117591911630921'
url_listing = 'https://facebook.com/marketplace/item/610256277272899/'

locations_coord = {'CANGGU': [-8.65583333, 115.13416667],
                   'SEMINIYAK': [-8.691049, 115.167751],
                   'ULUWATU': [-8.83333, 115.083],
                   'UBUD': [-8.50591, 115.26015],
                   'JIMBARAN': [-8.7891, 115.1643],
                   # LOVINA = Anturan
                   'LOVINA': [-8.1541335281821, 115.04939189972],
                   # SUKAWATI = Gianyar
                   'SUKAWATI': [-8.54274, 115.35226] 
                   }
